using System.Security.Cryptography;
using RestaurantSaaS.Application.Abstractions;

namespace RestaurantSaaS.Infrastructure.Services;

/// <summary>
/// The license keys of this host. A License Server has a private ECDSA P-256 key (from configuration, an environment variable or a file)
/// and signs licenses with it. Every app has the public keys it trusts (License:TrustedKeys). A host that holds a private key
/// trusts its own public key. In development a key can be created for you (License:AllowDevSigningKey).
/// The private key is never written to the repository or to a log.
/// </summary>
public sealed class LicenseKeyStore : ILicenseSigner, ILicenseKeyRing, IDisposable
{
    private readonly ECDsa? _privateKey;
    private readonly Dictionary<string, string> _trusted;

    public LicenseKeyStore(LicenseOptions options)
    {
        KeyId = options.SigningKeyId;
        _trusted = options.TrustedKeys
            .Where(pair => !string.IsNullOrWhiteSpace(pair.Value))
            .ToDictionary(pair => pair.Key, pair => pair.Value, StringComparer.Ordinal);

        var pem = Normalize(options.SigningPrivateKeyPem);

        if (string.IsNullOrWhiteSpace(pem) && !string.IsNullOrWhiteSpace(options.SigningPrivateKeyPath) && File.Exists(options.SigningPrivateKeyPath))
        {
            pem = File.ReadAllText(options.SigningPrivateKeyPath);
        }

        if (string.IsNullOrWhiteSpace(pem) && options.AllowDevSigningKey)
        {
            pem = LoadOrCreateDevKey();
        }

        if (!string.IsNullOrWhiteSpace(pem))
        {
            _privateKey = ECDsa.Create();
            _privateKey.ImportFromPem(pem);
            PublicKey = Convert.ToBase64String(_privateKey.ExportSubjectPublicKeyInfo());
            _trusted[KeyId] = PublicKey;
        }
    }

    public bool IsAvailable => _privateKey is not null;

    public string KeyId { get; }

    public string PublicKey { get; } = string.Empty;

    public byte[] Sign(byte[] data) =>
        _privateKey is null
            ? throw new InvalidOperationException("This host has no license signing key.")
            : _privateKey.SignData(data, HashAlgorithmName.SHA256);

    public bool TryGetPublicKey(string keyId, out string publicKey) => _trusted.TryGetValue(keyId, out publicKey!);

    public void Dispose() => _privateKey?.Dispose();

    // Environment variables cannot hold line breaks easily; "\n" written as text is accepted.
    private static string? Normalize(string? pem) => pem?.Replace("\\n", "\n");

    private static string LoadOrCreateDevKey()
    {
        var folder = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "RestoPOS");
        var path = Path.Combine(folder, "dev-license-signing.pem");

        if (File.Exists(path))
        {
            return File.ReadAllText(path);
        }

        Directory.CreateDirectory(folder);
        using var key = ECDsa.Create(ECCurve.NamedCurves.nistP256);
        var pem = key.ExportPkcs8PrivateKeyPem();
        File.WriteAllText(path, pem);
        return pem;
    }
}
