using RestaurantSaaS.Contracts.Dtos;
using RestaurantSaaS.Contracts.Paging;

namespace RestaurantSaaS.Contracts.Services;

/// <summary>License functions for the screens. Local (in-process) and Remote (HTTP) implementations exist.</summary>
public interface ILicenseService
{
    /// <summary>Open to everyone: the activation screen needs it before sign-in.</summary>
    Task<LicenseStatusDto> GetStatusAsync(CancellationToken ct = default);

    /// <summary>Activates a key. Desktop and on-premise: before sign-in when there is no license. Cloud: the owner, with the license permission.</summary>
    Task<LicenseStatusDto> ActivateAsync(ActivateLicenseRequest request, CancellationToken ct = default);

    /// <summary>Starts the free trial on a desktop or on-premise installation.</summary>
    Task<LicenseStatusDto> StartTrialAsync(StartTrialRequest request, CancellationToken ct = default);

    /// <summary>SuperAdmin: makes a batch of keys.</summary>
    Task<GeneratedLicenseKeysDto> GenerateKeysAsync(GenerateLicenseKeysRequest request, CancellationToken ct = default);

    /// <summary>SuperAdmin: the keys made so far.</summary>
    Task<PagedResult<LicenseKeyListItemDto>> GetKeysPageAsync(PageRequest request, CancellationToken ct = default);

    /// <summary>Frees this PC's activation on the License Server and removes the license file. The same key can be activated again later.</summary>
    Task<LicenseStatusDto> DeactivateAsync(CancellationToken ct = default);

    /// <summary>SuperAdmin: frees every PC of a key (for example when the PC was lost). The key can then be activated again.</summary>
    Task ResetKeyAsync(Guid licenseId, CancellationToken ct = default);

    /// <summary>SuperAdmin: plans to choose from when making keys.</summary>
    Task<IReadOnlyList<PlanOptionDto>> GetPlansAsync(CancellationToken ct = default);
}
