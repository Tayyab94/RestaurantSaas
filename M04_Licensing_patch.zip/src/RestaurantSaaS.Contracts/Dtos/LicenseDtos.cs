namespace RestaurantSaaS.Contracts.Dtos;

/// <summary>Where a business stands with its license. The UI shows banners from this; selling is blocked when <see cref="LicenseStatusDto.BlocksSelling"/> is true.</summary>
public enum LicenseState
{
    /// <summary>No license yet (desktop or on-premise before activation).</summary>
    NotActivated,
    /// <summary>A free trial is running.</summary>
    Trial,
    /// <summary>A paid license is valid.</summary>
    Active,
    /// <summary>A paid license is valid but ends soon.</summary>
    Expiring,
    /// <summary>The license ended a few days ago. Selling still works; renew now.</summary>
    Grace,
    /// <summary>The license ended. Selling is blocked.</summary>
    Expired,
    /// <summary>The license file or its database record was changed by hand.</summary>
    Tampered,
    /// <summary>The PC clock was moved back.</summary>
    ClockError,
    /// <summary>The license file is for another PC, or is older than the last one used.</summary>
    Mismatch,
    /// <summary>The license was revoked by us.</summary>
    Revoked,
    /// <summary>No license applies (platform administrator).</summary>
    NotRequired,
}

public static class LicenseStateExtensions
{
    /// <summary>True when the business may not take orders or payments.</summary>
    public static bool BlocksSelling(this LicenseState state) =>
        state is LicenseState.NotActivated or LicenseState.Expired or LicenseState.Tampered
            or LicenseState.ClockError or LicenseState.Mismatch or LicenseState.Revoked;
}

/// <summary>What the screens show about the license. Contains no secrets.</summary>
public sealed record LicenseStatusDto(
    LicenseState State,
    string LicenseType,
    string? PlanName,
    string? LicensedTo,
    string? KeyHint,
    DateTime? ExpiresAtUtc,
    int? DaysLeft,
    int? GraceDaysLeft,
    int MaxDevices,
    int MaxBranches,
    bool BlocksSelling,
    string Message,
    string Level);

public sealed record ActivateLicenseRequest(string Key, string UserName);

public sealed record StartTrialRequest(string UserName, string Phone, string? Email);

/// <summary>Asks the License Server (in-process or over HTTP) to activate a key for one PC.</summary>
public sealed record ServerActivateRequest(
    string Key,
    string UserName,
    string Fingerprint,
    IReadOnlyList<string> FingerprintParts,
    string? MachineName,
    string? OsVersion,
    string? AppVersion,
    string DeploymentMode);

public sealed record ServerTrialRequest(
    string UserName,
    string Phone,
    string? Email,
    string Fingerprint,
    IReadOnlyList<string> FingerprintParts,
    string? MachineName,
    string? OsVersion,
    string? AppVersion,
    string DeploymentMode);

/// <summary>The answer of the License Server: the signed license file content.</summary>
public sealed record LicenseIssueDto(string LicenseFile);

/// <summary>The app sends its signed license file as proof that it holds the activation it wants to free.</summary>
public sealed record ServerDeactivateRequest(string LicenseFile, string? Reason);

public sealed record GenerateLicenseKeysRequest(
    string LicenseType,
    Guid PlanId,
    int Quantity,
    int MaxActivations,
    int MaxDevices,
    int MaxBranches,
    string? Notes,
    decimal? SoldPrice);

/// <summary>The plain keys are shown once. Only a hash is stored.</summary>
public sealed record GeneratedLicenseKeysDto(string BatchNumber, IReadOnlyList<string> Keys);

public sealed record LicenseKeyListItemDto(
    Guid Id,
    string KeyHint,
    string LicenseType,
    string PlanName,
    string Status,
    int ActivationCount,
    int MaxActivations,
    string? LicensedUserName,
    DateTime? ExpiresAt,
    DateTime CreatedAt);

public sealed record PlanOptionDto(Guid Id, string Code, string Name);
