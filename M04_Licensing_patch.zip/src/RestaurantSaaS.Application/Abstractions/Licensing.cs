using RestaurantSaaS.Contracts.Dtos;
using RestaurantSaaS.Domain.Enums;

namespace RestaurantSaaS.Application.Abstractions;

public enum LicenseServerMode
{
    /// <summary>This host is the License Server itself (the cloud web, or a development desktop). It uses its own database.</summary>
    Embedded,

    /// <summary>The License Server is somewhere else; activation is an HTTPS call to <see cref="LicenseOptions.ServerUrl"/>.</summary>
    Remote,
}

/// <summary>Settings of the "License" section. Secrets (pepper, private key) come from environment variables in production.</summary>
public sealed class LicenseOptions
{
    public const string SectionName = "License";

    public LicenseServerMode ServerMode { get; set; } = LicenseServerMode.Remote;

    /// <summary>Base address of the License Server, for example https://license.example.com (Remote mode).</summary>
    public string? ServerUrl { get; set; }

    /// <summary>True on the host that answers /api/v1/license-server calls (the cloud web).</summary>
    public bool ServerEnabled { get; set; }

    /// <summary>Secret added when keys and phone numbers are hashed. Required on a License Server.</summary>
    public string? KeyPepper { get; set; }

    /// <summary>Where the signed license file is kept on this PC. Empty means the user's local application data folder.</summary>
    public string? FilePath { get; set; }

    public string SigningKeyId { get; set; } = "k1";

    /// <summary>The private signing key (PEM). Only the License Server has it.</summary>
    public string? SigningPrivateKeyPem { get; set; }

    public string? SigningPrivateKeyPath { get; set; }

    /// <summary>Development only: create a signing key in the user's data folder when none is configured.</summary>
    public bool AllowDevSigningKey { get; set; }

    /// <summary>Public keys this app trusts: key id to Base64 SubjectPublicKeyInfo.</summary>
    public Dictionary<string, string> TrustedKeys { get; set; } = new();
}

/// <summary>Signs licenses. Only a License Server has a private key.</summary>
public interface ILicenseSigner
{
    bool IsAvailable { get; }

    string KeyId { get; }

    /// <summary>Base64 SubjectPublicKeyInfo of the signing key.</summary>
    string PublicKey { get; }

    byte[] Sign(byte[] data);
}

/// <summary>The public keys this app trusts to check a license.</summary>
public interface ILicenseKeyRing
{
    bool TryGetPublicKey(string keyId, out string publicKey);
}

/// <summary>Hashed facts about this PC. The parts let a small hardware change (a new network card) pass.</summary>
public sealed record MachineFingerprint(string Hash, IReadOnlyList<string> Parts);

public interface IMachineFingerprint
{
    MachineFingerprint Get();
}

/// <summary>Reads and writes the signed license file of this installation.</summary>
public interface ILicenseFileStore
{
    string? Read();

    void Write(string content);

    void Delete();
}

/// <summary>Talks to the License Server: in-process (Embedded) or over HTTPS (Remote).</summary>
public interface ILicenseServerClient
{
    Task<LicenseIssueDto> ActivateAsync(ServerActivateRequest request, CancellationToken ct);

    Task<LicenseIssueDto> StartTrialAsync(ServerTrialRequest request, CancellationToken ct);

    Task DeactivateAsync(ServerDeactivateRequest request, CancellationToken ct);
}

/// <summary>The license gate: what state is this business in, and may it sell?</summary>
public interface ILicenseGate
{
    /// <summary>The state of the current business (cloud) or of this installation (desktop, on-premise). Cached for a few minutes.</summary>
    Task<LicenseStatusDto> GetStatusAsync(CancellationToken ct = default);

    /// <summary>Checks again now (start-up, after activation, hourly job).</summary>
    Task<LicenseStatusDto> RefreshAsync(LicenseCheckTrigger trigger, CancellationToken ct = default);

    /// <summary>Throws a LicenseException when selling is blocked.</summary>
    Task EnsureCanSellAsync(CancellationToken ct = default);
}
