namespace RestaurantSaaS.Application.Security;

/// <summary>
/// Put this on a request that sells: taking an order, a payment, a bill. When the license is expired,
/// tampered or missing, the pipeline stops the request with a LicenseException. Modules M09 and M11 use it.
/// </summary>
[AttributeUsage(AttributeTargets.Class)]
public sealed class RequireActiveLicenseAttribute : Attribute
{
}
