namespace RestaurantSaaS.Application.Common.Exceptions;

/// <summary>The license does not allow this action (HTTP 402). The stable code is "license_blocked".</summary>
public sealed class LicenseException(string message) : AppException("license_blocked", message, 402)
{
}
