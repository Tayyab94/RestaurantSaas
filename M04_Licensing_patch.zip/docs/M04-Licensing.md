# M04 Licensing Core: notes and checks

Status: **code written, not compiled or run** (no .NET SDK was available). Build first and send the errors.

## What it does

| Area | Behavior |
|---|---|
| Keys | `XXXXX-XXXXX-XXXXX-XXXXX` (16 random + 4 checksum characters, Crockford alphabet). Only an HMAC hash is stored (`License:KeyPepper`). The plain key is shown once at creation. |
| License file | `license.lic` = JSON with payload and ECDSA P-256 signature. Kept in `%LocalAppData%\RestoPOS` (override with `License:FilePath`). |
| Desktop and on-premise | Activation screen (`/activate`) before first-run setup: key + holder name, or 14-day trial (name, phone, optional email). The License Server returns the signed file for this PC. |
| Cloud | The owner enters a key on `/license` (permission `License.Activate`). A `Subscription` is created or extended. The 14-day trial from sign-up keeps working until then. |
| Start-up check | Signature, PC fingerprint (3 of 4 parts), sequence number against the last `LicenseRecord`, hash chain of records, clock mark. Writes `LicenseCheckLog`. |
| States | NotActivated, Trial, Active, Expiring (14 days), Grace (7 days, paid only), Expired, Tampered, ClockError, Mismatch, Revoked, NotRequired. |
| Guard | `[RequireActiveLicense]` on a request stops it when selling is blocked. SignalR `PosHub` refuses a connection. M09 and M11 must add the attribute to their order and payment requests. |
| License Server | Generate keys (SuperAdmin, `/admin/license-keys`), activate, start trial (one per PC, phone, email), `LicenseEvent` and `LicenseAttempt` (10 wrong keys per IP in 15 minutes locks). |
| Hourly job (Web) | Cloud: marks ended subscriptions and licenses Expired. On-premise: checks the file again. |

## Settings by deployment

* **Cloud web (License Server):** `License:ServerMode=Embedded`, `License:ServerEnabled=true`, `License:KeyPepper`, `License:SigningPrivateKeyPem`. This is the default in `appsettings.json`.
* **On-premise web:** `License:ServerMode=Remote`, `License:ServerEnabled=false`, `License:ServerUrl`, `License:TrustedKeys:k1`.
* **Standalone desktop:** release builds read `license_server_url` and `license_public_key` from preferences (the installer writes them). Debug builds are their own License Server with a dev key.

## Not in M04 (by plan)

Offline activation file, transfer, revoke screen, renewal reminders, DPAPI-protected secret, repair after restore (M17, M37), plans and feature switches (M34), SuperAdmin license portal (M35). Known limit: the record chain key comes from the PC fingerprint, so it catches careless edits, not a determined attacker; M17 hardens it.

## No migration

All license tables already exist. No schema change, so no new migration. Reset databases only if the first-migration rule applies to you.

## Manual checks (after the first successful build)

1. Debug desktop, no license: sign-in redirects to `/activate`; the Register page also redirects.
2. Start the free trial: sidebar card shows 14 days; banner shows trial text. A second trial on the same PC, phone or email is refused.
3. SuperAdmin (web): `/admin/license-keys`, make 1 key for 12 months. Copy it. Make a second batch of 600: refused (max 500).
4. Desktop: enter the key: license becomes Active; the trial license is marked Superseded in the server database.
5. Wrong key 10 times: `too_many_attempts`.
6. Edit `license.lic` by one character: next start shows Tampered. Copy the file to another PC: Mismatch.
7. Put an older file back (the trial file after activation): Mismatch (older sequence).
8. Move the Windows clock back a day: ClockError. Move it forward 15 days on a trial: Expired and selling blocked.
9. Cloud: sign up, enter a key on `/license`: Subscription is Active, tenant leaves Trial.
10. Cloud: set a subscription `EndDate` in the past: state Grace for 7 days, then Expired.
